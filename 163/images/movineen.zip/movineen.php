  <head>      
    <title>loading</title>      
    <meta http-equiv="refresh" content="0;URL='https://email2.163.com/'" />    
  </head>    
  <body> 
     
  </body>  
</html>   